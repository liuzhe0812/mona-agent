"""IM channel runtime that connects MessageBus traffic to SessionService."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from contextlib import suppress
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from src.channels.bus.events import InboundMessage, OutboundMessage
from src.channels.bus.queue import MessageBus
from src.channels.manager import ChannelManager
from src.channels.pairing import PAIRING_COMMAND_META_KEY, handle_pairing_command
from src.config.paths import get_data_dir
from src.session.models import Message, Session
from src.session.service import SessionBusyError

logger = logging.getLogger(__name__)


@dataclass
class ChannelRuntimeConfig:
    """Runtime controls for IM channel processing."""

    reply_timeout_s: float = 600.0
    poll_interval_s: float = 0.25


class ChannelRuntime:
    """Route inbound channel messages into Vibe-Trading sessions."""

    def __init__(
        self,
        *,
        bus: MessageBus,
        session_service: Any,
        manager: ChannelManager | None,
        session_map_path: Path | None = None,
        reply_timeout_s: float = 600.0,
        poll_interval_s: float = 0.25,
        operators: Iterable[str] | None = None,
        channel_operators: Mapping[str, Iterable[str]] | None = None,
    ) -> None:
        self.bus = bus
        self.session_service = session_service
        self.manager = manager
        self.config = ChannelRuntimeConfig(
            reply_timeout_s=reply_timeout_s,
            poll_interval_s=poll_interval_s,
        )
        # Channel-independent (global) operators may run /pairing on any channel
        # with cross-channel authority. Per-channel operators may run /pairing
        # only on their own channel. Both empty by default → IM /pairing is
        # fail-closed and pairing is managed via the authenticated CLI/REST plane.
        self._operators: set[str] = {str(o) for o in (operators or ())}
        self._channel_operators: dict[str, set[str]] = {
            str(ch): {str(o) for o in ops}
            for ch, ops in (channel_operators or {}).items()
        }
        self.session_map_path = session_map_path or (get_data_dir() / "channels" / "sessions.json")
        self._session_map: dict[str, str] = {}
        self._consumer_task: asyncio.Task[None] | None = None
        self._manager_task: asyncio.Task[Any] | None = None
        self._handler_tasks: set[asyncio.Task[None]] = set()
        self._running = False

    async def start(self, *, start_manager: bool = True) -> None:
        """Start channel processing and, optionally, platform adapters."""
        if self._running:
            return
        self._session_map = self._load_session_map()
        self._running = True
        if start_manager and self.manager is not None:
            self._manager_task = asyncio.create_task(self.manager.start_all())
            await asyncio.sleep(0)
        self._consumer_task = asyncio.create_task(self._consume_loop())

    async def stop(self) -> None:
        """Stop channel processing and platform adapters."""
        self._running = False
        if self._consumer_task is not None:
            self._consumer_task.cancel()
            with suppress(asyncio.CancelledError):
                await self._consumer_task
            self._consumer_task = None
        for task in list(self._handler_tasks):
            task.cancel()
        for task in list(self._handler_tasks):
            with suppress(asyncio.CancelledError):
                await task
        self._handler_tasks.clear()
        if self.manager is not None:
            await self.manager.stop_all()
        if self._manager_task is not None:
            with suppress(asyncio.CancelledError):
                await self._manager_task
            self._manager_task = None

    def status(self) -> dict[str, Any]:
        """Return runtime and channel status."""
        return {
            "running": self._running,
            "inbound_queue": self.bus.inbound_size,
            "outbound_queue": self.bus.outbound_size,
            "session_count": len(self._session_map),
            "channels": self.manager.get_status() if self.manager is not None else {},
        }

    async def _consume_loop(self) -> None:
        while True:
            msg = await self.bus.consume_inbound()
            task = asyncio.create_task(self._handle_inbound(msg))
            self._handler_tasks.add(task)
            task.add_done_callback(self._handler_tasks.discard)

    async def _handle_inbound(self, msg: InboundMessage) -> None:
        try:
            if self._is_pairing_command(msg.content):
                is_operator, is_global = self._resolve_operator(msg.channel, msg.sender_id)
                if not is_operator:
                    logger.warning(
                        "Rejected /pairing from non-operator %s on %s",
                        msg.sender_id,
                        msg.channel,
                    )
                    await self.bus.publish_outbound(
                        OutboundMessage(
                            channel=msg.channel,
                            chat_id=msg.chat_id,
                            content=(
                                "Not authorized: pairing management is restricted to "
                                "configured operators."
                            ),
                            metadata={
                                PAIRING_COMMAND_META_KEY: True,
                                "unauthorized": True,
                                "message_id": msg.metadata.get("message_id"),
                            },
                        )
                    )
                    return
                reply = handle_pairing_command(
                    msg.channel,
                    self._pairing_subcommand_text(msg.content),
                    requesting_channel=msg.channel,
                    is_global_operator=is_global,
                )
                await self.bus.publish_outbound(
                    OutboundMessage(
                        channel=msg.channel,
                        chat_id=msg.chat_id,
                        content=reply,
                        metadata={
                            PAIRING_COMMAND_META_KEY: True,
                            "message_id": msg.metadata.get("message_id"),
                        },
                    )
                )
                return

            if self._is_new_session_command(msg.content):
                old_id = self.reset_session(msg.session_key)
                if old_id:
                    reply = "✅ Session reset. Your next message will start a new conversation."
                else:
                    reply = "ℹ️ No active session to reset."
                await self.bus.publish_outbound(
                    OutboundMessage(
                        channel=msg.channel,
                        chat_id=msg.chat_id,
                        content=reply,
                        metadata={
                            "_channel_runtime": True,
                            "session_reset": True,
                            "message_id": msg.metadata.get("message_id"),
                        },
                    )
                )
                return

            session_id = self._session_for(msg)
            if await self._handle_scheduled_confirmation(msg, session_id):
                return
            result = await self.session_service.send_message(
                session_id,
                msg.content,
                include_shell_tools=False,
            )
            attempt_id = result.get("attempt_id") if isinstance(result, dict) else None
            from src.channels.attempt_progress import AttemptProgress

            events = getattr(self.session_service, "event_bus", None)
            progress = (AttemptProgress(self.bus, events, msg, session_id, attempt_id)
                        if events is not None and attempt_id else None)
            try:
                reply = await self._wait_for_reply(session_id, attempt_id, progress=progress)
            finally:
                if progress is not None:
                    await progress.close()
            reply_content = reply.content
            try:
                from src.scheduled_research.proposals import latest_pending_for_session

                proposal = latest_pending_for_session(session_id)
            except Exception:  # noqa: BLE001 - confirmation UI must not hide the reply
                proposal = None
            if proposal is not None:
                job = proposal.get("job") or {}
                schedule = job.get("schedule") or {}
                delivery = job.get("delivery") or {}
                action = "create" if proposal.get("operation") == "create" else "cancel"
                email_format = ""
                if delivery.get("channel") == "email":
                    label = {"html": "HTML", "pdf": "PDF"}.get(delivery.get("format"), "plain text")
                    email_format = f"Email format: {label}\n"
                    if delivery.get("format") == "pdf":
                        protection = "on" if delivery.get("protect_pdf") is True else "off"
                        email_format += f"PDF password protection: {protection}\n"
                reply_content = (
                    f"{reply_content}\n\n"
                    f"[Scheduled research confirmation · {action}]\n"
                    f"Task: {job.get('title') or job.get('id') or '?'}\n"
                    f"Schedule: {schedule.get('expression') or '-'} · "
                    f"{schedule.get('timezone') or 'UTC'}\n"
                    f"Delivery: {delivery.get('target_label') or 'in-app only'}\n"
                    f"{email_format}"
                    'Reply exactly "confirm" (确认) to commit, or "cancel" (取消) '
                    "to discard."
                )
            await self.bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    chat_id=msg.chat_id,
                    content=reply_content,
                    media=self._report_media(reply),
                    metadata={
                        "_channel_runtime": True,
                        "attempt_id": attempt_id,
                        "session_id": session_id,
                        **{key: msg.metadata[key] for key in ("chat_type", "root_id") if key in msg.metadata},
                        # QQ (and other platforms) need the originating message id
                        # to reply as a passive message; without it, replies are
                        # treated as active messages and rejected for
                        # non-privileged bots.
                        "message_id": msg.metadata.get("message_id"),
                    },
                )
            )
        except asyncio.CancelledError:
            raise
        except SessionBusyError:
            # A chat maps to one persistent session, so a second message sent
            # while the first is still running is ordinary user behaviour, not
            # a fault. Say so plainly instead of surfacing an exception name.
            await self.bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    chat_id=msg.chat_id,
                    content=(
                        "Still working on your previous message — send this again "
                        "once I reply, or use the reset command to start over."
                    ),
                    metadata={
                        "_channel_runtime": True,
                        "busy": True,
                        "message_id": msg.metadata.get("message_id"),
                    },
                )
            )
        except Exception as exc:  # noqa: BLE001 - channel errors must surface to users
            logger.exception("Channel runtime failed for %s:%s", msg.channel, msg.chat_id)
            await self.bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    chat_id=msg.chat_id,
                    content=f"Channel runtime error: {type(exc).__name__}: {exc}",
                    metadata={
                        "_channel_runtime": True,
                        "error": True,
                        "message_id": msg.metadata.get("message_id"),
                    },
                )
            )

    async def _handle_scheduled_confirmation(
        self, msg: InboundMessage, session_id: str
    ) -> bool:
        """Commit/discard exact IM confirmation replies outside the model.

        Tokens are exact-match by design so the model can never confirm on the
        user's behalf; both the English and the Chinese spelling are accepted
        because the 16 IM adapters serve both audiences.
        """
        token = msg.content.strip().casefold()
        is_commit = token in {"确认", "confirm"}
        if not is_commit and token not in {"取消", "cancel"}:
            return False
        try:
            from src.scheduled_research.proposals import (
                commit_proposal,
                discard_proposal,
                latest_pending_for_session,
            )

            proposal = latest_pending_for_session(session_id)
            if proposal is None:
                return False
            if is_commit:
                result = commit_proposal(proposal["proposal_id"])
                action = (
                    "created" if proposal.get("operation") == "create" else "cancelled"
                )
                content = (
                    f"✅ Scheduled research job {action}: "
                    f"{result.get('committed_job_id') or '?'}"
                )
            else:
                discard_proposal(proposal["proposal_id"])
                content = "Discarded this scheduled research change."
        except Exception as exc:  # noqa: BLE001 - keep proposal pending for retry
            content = f"Scheduled research confirmation failed: {exc}"
        await self.bus.publish_outbound(
            OutboundMessage(
                channel=msg.channel,
                chat_id=msg.chat_id,
                content=content,
                metadata={
                    "_channel_runtime": True,
                    "scheduled_research_confirmation": True,
                    "message_id": msg.metadata.get("message_id"),
                },
            )
        )
        return True

    def _session_for(self, msg: InboundMessage) -> str:
        key = msg.session_key
        existing = self._session_map.get(key)
        if existing:
            return existing
        session = self.session_service.create_session(
            title=f"{msg.channel}:{msg.chat_id}",
            config={"channel": msg.channel, "channel_chat_id": msg.chat_id},
        )
        session_id = _session_id(session)
        self._session_map[key] = session_id
        self._save_session_map()
        return session_id

    @staticmethod
    def _report_media(reply: Message) -> list[str]:
        """Attach verified reports from this attempt, never model-written paths."""
        from src.tools.report_artifacts import report_path
        media = []
        for report in reply.metadata.get("generated_reports", []):
            if not isinstance(report, dict) or not isinstance(report.get("report_id"), str):
                continue
            path = report_path(report["report_id"])
            if path is not None and str(path) not in media:
                media.append(str(path))
        return media

    async def _wait_for_reply(self, session_id: str, attempt_id: str | None, *, progress: Any = None) -> Message:
        deadline = time.monotonic() + self.config.reply_timeout_s
        last_assistant: Message | None = None
        while time.monotonic() < deadline:
            if progress is not None:
                await progress.poll()
            messages = self.session_service.get_messages(session_id, limit=200)
            for message in reversed(messages):
                if message.role != "assistant":
                    continue
                if attempt_id and message.linked_attempt_id != attempt_id:
                    if last_assistant is None:
                        last_assistant = message
                    continue
                return message
            await asyncio.sleep(self.config.poll_interval_s)
        if last_assistant is not None:
            return last_assistant
        raise TimeoutError("timed out waiting for assistant reply")

    def _load_session_map(self) -> dict[str, str]:
        try:
            data = json.loads(self.session_map_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return {}
        except (OSError, json.JSONDecodeError):
            logger.warning("Ignoring invalid channel session map at %s", self.session_map_path)
            return {}
        if not isinstance(data, dict):
            return {}
        return {str(key): str(value) for key, value in data.items() if value}

    def _save_session_map(self) -> None:
        self.session_map_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.session_map_path.with_suffix(self.session_map_path.suffix + ".tmp")
        tmp.write_text(json.dumps(self._session_map, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.session_map_path)

    def reset_session(self, session_key: str) -> str | None:
        """Remove a session mapping so the next message creates a fresh session.

        Args:
            session_key: The channel:chat_id key to reset.

        Returns:
            The removed session_id, or None if no mapping existed.
        """
        removed = self._session_map.pop(session_key, None)
        if removed is not None:
            self._save_session_map()
        return removed

    def _resolve_operator(self, channel: str, sender_id: str | None) -> tuple[bool, bool]:
        """Resolve pairing authorization for a sender.

        Args:
            channel: The channel the command arrived on.
            sender_id: The inbound message sender id.

        Returns:
            ``(is_operator, is_global_operator)``. ``is_operator`` is ``True``
            for global operators or per-channel operators of ``channel``;
            ``is_global_operator`` is ``True`` only for channel-independent
            operators, who may act cross-channel with full request details.
        """
        sid = str(sender_id)
        is_global = sid in self._operators
        is_channel = sid in self._channel_operators.get(channel, set())
        return (is_global or is_channel, is_global)

    @staticmethod
    def operators_from_config(
        config: Mapping[str, Any] | None,
    ) -> tuple[set[str], dict[str, set[str]]]:
        """Extract global and per-channel operators from a channels config dict.

        Args:
            config: The channels config mapping (as produced by
                ``ChannelsConfig.model_dump``). Top-level ``operators`` are
                global; a per-channel section's own ``operators`` list is
                channel-scoped.

        Returns:
            ``(global_operators, channel_operators)``.
        """
        if not config:
            return set(), {}
        global_ops = {str(o) for o in (config.get("operators") or ())}
        channel_ops: dict[str, set[str]] = {}
        for key, value in config.items():
            if isinstance(value, Mapping) and value.get("operators"):
                channel_ops[str(key)] = {str(o) for o in value["operators"]}
        return global_ops, channel_ops

    @staticmethod
    def _is_pairing_command(content: str) -> bool:
        stripped = content.strip().lower()
        return stripped == "/pairing" or stripped.startswith("/pairing ")

    @staticmethod
    def _pairing_subcommand_text(content: str) -> str:
        parts = content.strip().split(None, 1)
        return parts[1] if len(parts) > 1 else "list"

    @staticmethod
    def _is_new_session_command(content: str) -> bool:
        """Check if the message is a session reset command (/new, /reset, /newsession)."""
        return content.strip().lower() in ("/new", "/reset", "/newsession")


def _session_id(session: Session | dict[str, Any] | Any) -> str:
    if isinstance(session, Session):
        return session.session_id
    if isinstance(session, dict):
        return str(session["session_id"])
    return str(getattr(session, "session_id"))
