"""DataLoader Protocol, shared exceptions, retry helpers, and loader cache.

The retry/budget helpers are the canonical pattern for any loader that calls
a flaky external API: a wall-clock deadline plus a small backoff schedule
applied only to a declared transient exception class. New loaders should
import :func:`check_budget` and :func:`retry_with_budget` rather than
re-implementing the loop.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import logging
import os
import re
import time
import uuid
from pathlib import Path
from typing import Callable, Protocol, TypeVar, runtime_checkable

import pandas as pd

logger = logging.getLogger(__name__)


# The supported LSE contract settles in GBP. Yahoo may declare an individual
# ``.L`` line in pence (``GBp``), pounds (``GBP``), another currency, or no
# currency at all. Loaders must normalize declared pence to pounds and reject
# every non-GBP/unknown line before the static GBP market accounting sees it.
_GBP_PENCE_CURRENCY = "GBp"
_PRICE_COLUMNS = ("open", "high", "low", "close")
_UK_EQUITY_PATTERN = re.compile(r"^[A-Z0-9&.\-]+\.L$", re.I)
# Venues that list lines in a second currency, whose market is one static
# pool in the first. BYMA quotes GGAL.BA in ARS and GGALD.BA in USD (the
# trailing D is not a rule: YPFD.BA is a peso line); the TSX quotes DLR.TO in
# CAD and DLR-U.TO in USD. Yahoo declares each, and every priced source in
# these markets' chains is Yahoo or yfinance, so the declared currency decides.
_SINGLE_CURRENCY_VENUES: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"^[A-Z0-9&.\-]+\.BA$", re.I), "ARS"),
    (re.compile(r"^[A-Z0-9]+\.SA$", re.I), "BRL"),
    (re.compile(r"^[A-Z0-9&.\-]+\.(?:TO|V)$", re.I), "CAD"),
)


def _venue_currency(code: str) -> str | None:
    """Return the one currency a symbol's venue pool accepts, or None if unconstrained."""
    code = str(code).strip()
    return next(
        (cur for pattern, cur in _SINGLE_CURRENCY_VENUES if pattern.match(code)), None
    )


def is_lse_symbol(code: str) -> bool:
    """Return whether a project symbol uses the supported LSE ``.L`` form.

    The suffix identifies the venue, not the quote currency. Every caller must
    still inspect source metadata through :func:`normalize_lse_quote_currency`
    before emitting bars.
    """
    return bool(_UK_EQUITY_PATTERN.match(str(code).strip()))


def scale_pence_to_currency(
    frame: pd.DataFrame, currency: str
) -> tuple[pd.DataFrame, str]:
    """Convert GBp-quoted OHLC prices to GBP (÷100) when the source says GBp.

    Args:
        frame: OHLCV frame with float price columns.
        currency: Quote currency declared by the source (e.g. ``"GBp"`` for
            LSE pence-quoted names; ``"USD"``/``"EUR"``/``"GBP"`` pass
            through).

    Returns:
        ``(frame, applied)``: the (possibly scaled) frame, and the conversion
        applied — ``"GBp→GBP (÷100)"`` when scaled, else ``"none"``.
    """
    if currency != _GBP_PENCE_CURRENCY or frame is None or frame.empty:
        return frame, "none"
    scaled = frame.copy()
    for column in _PRICE_COLUMNS:
        scaled[column] = scaled[column] / 100.0
    return scaled, "GBp→GBP (÷100)"


def declared_currency_required(code: str) -> bool:
    """Return whether ``code``'s suffix names a venue that quotes in several currencies.

    A loader must read the source's declared currency for such a symbol and
    pass it to :func:`normalize_declared_quote_currency` before emitting bars.
    """
    return is_lse_symbol(code) or _venue_currency(code) is not None


def normalize_declared_quote_currency(
    frame: pd.DataFrame, code: str, currency: str | None
) -> pd.DataFrame:
    """Hold a frame to its market's currency contract and record the declared quote.

    Args:
        frame: Normalized OHLCV frame.
        code: The project symbol the frame belongs to.
        currency: Quote currency declared by the source, if any.

    Returns:
        The frame with ``attrs["quote_currency"]`` set whenever a currency was
        declared (GBP for an LSE line after pence scaling).

    Raises:
        ValueError: If an LSE line is not declared GBP/GBp, or a BYMA / TSX
            line is not declared in its market's currency -- each would enter a
            single-currency pool in the wrong unit.
    """
    if is_lse_symbol(code):
        return normalize_lse_quote_currency(frame, currency)
    declared = currency.strip() if isinstance(currency, str) else ""
    required = _venue_currency(code)
    if required is not None and declared != required:
        raise ValueError(
            f"{code} must be quoted in {required} to enter that market's pool; "
            f"the source declared {declared or 'no currency'!r}"
        )
    if declared:
        frame.attrs["quote_currency"] = declared
    return frame


def normalize_lse_quote_currency(
    frame: pd.DataFrame, currency: str | None
) -> pd.DataFrame:
    """Normalize a declared LSE quote into the engine's GBP-only contract.

    Args:
        frame: Normalized OHLCV frame.
        currency: Quote currency declared by the source.

    Returns:
        A frame quoted in GBP with per-symbol conversion provenance attached.

    Raises:
        ValueError: If the source declares USD/another currency or omits the
            currency. Passing such bars into the static ``uk_equity=GBP``
            accounting contract would silently mix currencies.
    """
    declared = currency.strip() if isinstance(currency, str) else ""
    normalized = frame.copy()
    if declared in {_GBP_PENCE_CURRENCY, "p"}:
        normalized, conversion = scale_pence_to_currency(
            normalized, _GBP_PENCE_CURRENCY
        )
    elif declared == "GBP":
        conversion = "none"
    else:
        label = declared or "missing"
        raise ValueError(
            "LSE quote currency must be declared as GBP or GBp; " f"got {label!r}"
        )

    normalized.attrs["quote_currency"] = "GBP"
    normalized.attrs["currency_conversion"] = conversion
    return normalized


class NoAvailableSourceError(Exception):
    """Raised when no data source is available for a given market."""


def validate_date_range(start_date: str, end_date: str) -> None:
    """Validate that start_date <= end_date.

    Args:
        start_date: Start date string (YYYY-MM-DD).
        end_date: End date string (YYYY-MM-DD).

    Raises:
        ValueError: If dates are invalid or start > end.
    """
    try:
        start = pd.Timestamp(start_date)
        end = pd.Timestamp(end_date)
    except Exception as exc:
        raise ValueError(
            f"Invalid date format: start={start_date!r}, end={end_date!r}"
        ) from exc
    if start > end:
        raise ValueError(f"start_date ({start_date}) > end_date ({end_date})")


def validate_ohlc(
    frame: pd.DataFrame,
    *,
    strategy: str = "drop",
    allow_nonpositive_prices: bool = False,
) -> pd.DataFrame:
    """Drop, flag, or reject bars that violate OHLC invariants.

    Loaders only drop NaN rows, so structurally dirty bars — ``high < low``,
    a non-positive price, or a high/low that fails to bracket open/close —
    flow straight into the backtest and surface downstream as NaN/inf metrics
    that break the strict (``allow_nan=False``) JSON serializers. This is the
    canonical loader-boundary check; call it after the existing ``dropna`` so a
    single sanity pass guards every source.

    Structural invariants (``high < low`` and high/low failing to bracket
    open/close) are always enforced. The *positivity* invariant is
    configurable: some markets clear at or below zero legitimately (European
    day-ahead power routinely prints negative), and a rolling statistic over a
    silently gap-filled series is worse than a well-defined negative bar. When
    ``allow_nonpositive_prices`` is set, negative prices pass through and only
    an exactly-zero price is rejected — zero is genuinely undefined for
    notional sizing (``size = notional / price``) and margin, whereas a
    negative price is handled by ``abs()``-based sizing in the engine.

    Args:
        frame: OHLCV frame with at least ``open``/``high``/``low``/``close``
            columns. NaN handling is left to the caller's ``dropna``.
        strategy: ``"drop"`` (remove offending rows, default), ``"warn"``
            (log and keep), or ``"raise"`` (raise on any violation).
        allow_nonpositive_prices: when ``True``, keep bars with negative
            prices and reject only exact zeros; when ``False`` (default,
            unchanged behavior) reject any price ``<= 0``.

    Returns:
        The frame with invalid rows removed (``"drop"``) or unchanged
        (``"warn"``). A frame that is empty or lacks OHLC columns is returned
        as-is.

    Raises:
        ValueError: ``strategy="raise"`` and at least one bar is invalid.
    """
    required = ("open", "high", "low", "close")
    if frame.empty or not all(col in frame.columns for col in required):
        return frame

    open_, high, low, close = (frame[c] for c in required)
    structural = (
        (high < low) | (high < open_) | (high < close) | (low > open_) | (low > close)
    )
    if allow_nonpositive_prices:
        nonpositive = (open_ == 0) | (high == 0) | (low == 0) | (close == 0)
    else:
        nonpositive = (open_ <= 0) | (high <= 0) | (low <= 0) | (close <= 0)
    invalid = structural | nonpositive
    n_invalid = int(invalid.sum())
    if n_invalid == 0:
        return frame

    if strategy == "raise":
        raise ValueError(f"{n_invalid} bar(s) violate OHLC invariants")
    if strategy == "warn":
        logger.warning(
            "OHLC validation: %d bar(s) violate invariants (kept)", n_invalid
        )
        return frame
    logger.warning("OHLC validation: dropping %d invalid bar(s)", n_invalid)
    return frame[~invalid]


# ---------------------------------------------------------------------------
# Bounded retry / budget helpers (shared by ccxt_loader, okx, and any future
# loader calling a flaky external API).
# ---------------------------------------------------------------------------

DEFAULT_BACKOFF: tuple[float, ...] = (0.5, 1.5, 4.0)
DEFAULT_MAX_RETRIES = 3


#: Bar sizes built from daily bars instead of asked of a loader (#1479). Every
#: source serves daily bars; few serve weekly or monthly, and those that do
#: disagree on where a week ends and how its bar is adjusted, so one resample
#: here keeps a weekly bar the same thing whichever source served the days. A
#: bar covers one calendar week (Monday to Sunday) or month.
RESAMPLED_INTERVALS = {"1W": "W-SUN", "1M": "M"}

#: Columns a period bar sums. ``vwap`` is weighted by volume (NaN without a
#: volume column), ``funding_rate`` (a per-settlement rate) is averaged,
#: ``open``/``high``/``low`` take their own rule, and every other column is a
#: level and takes the period's last value.
_SUMMED_COLUMNS = frozenset({"volume", "amount"})


def source_interval(interval: str) -> str:
    """Return the bar size to request from a loader when serving ``interval``.

    Args:
        interval: The bar size the caller asked for.

    Returns:
        ``"1D"`` for a resampled interval, otherwise ``interval`` unchanged.
    """
    return "1D" if interval in RESAMPLED_INTERVALS else interval


def resample_bars(frame: pd.DataFrame, interval: str) -> pd.DataFrame:
    """Aggregate daily bars into ``interval`` bars.

    Each bar is stamped with the last trading day inside its period, which is
    when its close becomes known, so a signal on it never sees a later day and
    a partial first or last period stays a bar dated inside that period.

    Args:
        frame: Daily bars on a ``DatetimeIndex``.
        interval: A key of :data:`RESAMPLED_INTERVALS`; any other interval
            returns ``frame`` unchanged.

    Returns:
        One row per period: first open, highest high, lowest low, last close,
        summed volume and amount, volume-weighted vwap, mean funding rate, last
        value of any other column. Frame attributes (quote currency) are kept.
    """
    if interval not in RESAMPLED_INTERVALS or frame.empty:
        return frame
    index = pd.DatetimeIndex(frame.index)
    naive = index.tz_localize(None) if index.tz is not None else index
    periods = naive.to_period(RESAMPLED_INTERVALS[interval])
    grouped = frame.groupby(periods)
    columns = {}
    for column in frame.columns:
        values = grouped[column]
        if column == "open":
            columns[column] = values.first()
        elif column == "high":
            columns[column] = values.max()
        elif column == "low":
            columns[column] = values.min()
        elif column in _SUMMED_COLUMNS:
            columns[column] = values.sum(min_count=1)
        elif column == "funding_rate":
            columns[column] = values.mean()
        elif column == "vwap":
            if "volume" in frame.columns:
                traded = (
                    (frame["vwap"] * frame["volume"]).groupby(periods).sum(min_count=1)
                )
                columns[column] = traded / grouped["volume"].sum(min_count=1)
            else:
                columns[column] = values.first() * float("nan")
        else:
            columns[column] = values.last()
    out = pd.DataFrame(columns, columns=frame.columns)
    stamps = pd.Series(index, index=periods).groupby(level=0).max()
    out.index = pd.DatetimeIndex(stamps.loc[out.index], name=frame.index.name)
    out.attrs = dict(frame.attrs)
    return out


def positive_env_int(name: str, default: int) -> int:
    """Read a positive integer env var, warning and falling back on invalid values."""
    raw = os.getenv(name)  # noqa: env-gate — generic env var helper
    if raw is None or not raw.strip():
        return default
    try:
        value = int(raw)
    except ValueError:
        logger.warning("invalid %s=%r, using default %s", name, raw, default)
        return default
    if value <= 0:
        logger.warning("non-positive %s=%r, using default %s", name, raw, default)
        return default
    return value


def positive_env_float(name: str, default: float) -> float:
    """Read a positive float env var, warning and falling back on invalid values."""
    raw = os.getenv(name)  # noqa: env-gate — generic env var helper
    if raw is None or not raw.strip():
        return default
    try:
        value = float(raw)
    except ValueError:
        logger.warning("invalid %s=%r, using default %s", name, raw, default)
        return default
    if value <= 0:
        logger.warning("non-positive %s=%r, using default %s", name, raw, default)
        return default
    return value


def check_budget(deadline: float, label: str, budget_s: float | None = None) -> None:
    """Raise :class:`TimeoutError` if the monotonic clock has crossed ``deadline``.

    Use this between pages of a paginated fetch to fail fast instead of
    grinding through more requests once the wall-clock budget is gone.

    Args:
        deadline: ``time.monotonic()`` instant past which we abort.
        label: Free-form label used in the exception message
            (e.g. ``"ccxt fetch for BTC/USDT"``).
        budget_s: Original budget in seconds, included verbatim in the
            message when present.
    """
    if time.monotonic() > deadline:
        suffix = (
            f" exceeded {budget_s:.0f}s budget"
            if budget_s is not None
            else " exceeded budget"
        )
        raise TimeoutError(f"{label}{suffix}")


_T = TypeVar("_T")


def retry_with_budget(
    fn: Callable[[], _T],
    *,
    transient: type[BaseException] | tuple[type[BaseException], ...],
    deadline: float,
    label: str,
    max_retries: int = DEFAULT_MAX_RETRIES,
    backoff: tuple[float, ...] = DEFAULT_BACKOFF,
) -> _T:
    """Call ``fn`` with a bounded retry budget on declared transient errors.

    Between attempts sleeps ``min(backoff[attempt], remaining_budget)`` so a
    short remaining budget never spends the full backoff. The terminal
    transient failure — whether ``max_retries`` is exhausted OR the deadline
    has passed — is wrapped in :class:`TimeoutError`, preserving the original
    exception as ``__cause__``. Anything not in ``transient`` propagates
    unchanged on the first occurrence (we never retry an exception class
    the caller didn't opt in to).

    Args:
        fn: Zero-arg callable producing the result.
        transient: Exception class(es) considered transient and retryable.
        deadline: ``time.monotonic()`` instant past which retries are aborted.
        label: Free-form label used in the TimeoutError message
            (e.g. ``"OKX fetch for BTC-USDT"``).
        max_retries: Additional attempts after the first call. Total
            attempts = ``max_retries + 1``.
        backoff: Per-retry sleep seconds. Must have at least
            ``max_retries`` entries.

    Returns:
        Whatever ``fn`` returns.

    Raises:
        ValueError: ``backoff`` is shorter than ``max_retries``.
        TimeoutError: All retries exhausted or the deadline crossed.
        Any non-transient exception: Propagated unchanged from ``fn``.
    """
    if len(backoff) < max_retries:
        raise ValueError(
            f"backoff has {len(backoff)} entries; need >= max_retries ({max_retries})"
        )
    for attempt in range(max_retries + 1):
        try:
            return fn()
        except transient as exc:
            remaining = deadline - time.monotonic()
            if attempt == max_retries or remaining <= 0:
                raise TimeoutError(
                    f"{label} failed after {attempt + 1} attempt(s): {exc}"
                ) from exc
            time.sleep(min(backoff[attempt], max(0.0, remaining)))
    raise AssertionError(
        "unreachable: retry loop must return or raise"
    )  # pragma: no cover


# ---------------------------------------------------------------------------
# Opt-in local loader cache.
# ---------------------------------------------------------------------------

LOADER_CACHE_ENV = "VIBE_TRADING_DATA_CACHE"
LOADER_CACHE_ROOT_ENV = "VIBE_TRADING_DATA_CACHE_ROOT"
_LOADER_CACHE_TRUE_VALUES = {"1", "true", "yes", "on"}
# Bump when the key payload or on-disk layout changes so stale entries are
# simply never matched (old files become unreachable garbage, safe to delete).
# v4: baostock volume normalized from shares to lots (#1062) — entries cached
# under the pre-normalization unit must never be served again.
# v5: UK (.L) prices normalized from GBp to GBP (÷100) (#1206).
# v6: LSE quote currency is fail-closed and per-symbol conversion provenance is
# persisted. v5 USD/unknown .L entries must never be served as static GBP.
# v7: tencent fqkline paginates backward (#1410) — entries cached under the
# forward walk hold tail-truncated multi-year series and must never be served.
# v8: FMP/Tiingo keep one adjusted/raw basis and cached frames retain their
# actual adjustment stamp. Older entries may contain artificial return jumps.
# v9: SEC successor/predecessor facts extend historical coverage. Old cached
# panels may omit the predecessor's filings and must be rebuilt.
_LOADER_CACHE_VERSION = 9
_LOADER_FRAME_METADATA_ATTRS = ("quote_currency", "currency_conversion", "adjustment")


def loader_cache_enabled() -> bool:
    """Return whether the local market-data cache is explicitly enabled.

    Returns:
        True only when the config yields a real ``True``. Any other value —
        including a truthy non-bool from a stubbed config — leaves the opt-in
        cache off.
    """
    from src.config.accessor import get_env_config

    return get_env_config().data.vibe_trading_data_cache is True


def loader_cache_root() -> Path:
    """Return the root directory for opt-in loader cache files.

    The configured override is honored only when it is a genuine non-blank
    ``str``. A non-string value (e.g. a stubbed config in tests) would
    otherwise reach ``Path()`` via ``__fspath__`` and yield a *relative* path,
    which resolves against the CWD and writes market data inside the working
    tree — the repository forbids caching data in the repo.

    Returns:
        The configured cache root, or the default under the user's home.
    """
    from src.config.accessor import get_env_config

    root = get_env_config().data.vibe_trading_data_cache_root
    if isinstance(root, str) and root.strip():
        return Path(root).expanduser()
    return Path.home() / ".vibe-trading" / "cache" / "loaders"


def make_loader_cache_key(
    *,
    source: str,
    symbol: str,
    timeframe: str,
    start_date: str,
    end_date: str,
    fields: list[str] | tuple[str, ...] | None = None,
) -> str:
    """Build a stable content-addressed key for one loader payload."""
    payload = _loader_cache_payload(
        source=source,
        symbol=symbol,
        timeframe=timeframe,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
    )
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def loader_cache_path(
    *,
    source: str,
    symbol: str,
    timeframe: str,
    start_date: str,
    end_date: str,
    fields: list[str] | tuple[str, ...] | None = None,
) -> Path:
    """Return the parquet cache path for one loader payload."""
    key = make_loader_cache_key(
        source=source,
        symbol=symbol,
        timeframe=timeframe,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
    )
    source_dir = _sanitize_cache_segment(source)
    return loader_cache_root() / source_dir / f"{key}.parquet"


def loader_cache_range_is_final(end_date: str) -> bool:
    """Return whether ``end_date`` is settled enough to cache.

    The key is content-addressed on ``end_date`` but not on wall-clock fetch
    time, so caching a range whose last bar is still forming (``end_date`` today
    or in the future) would pin a provisional bar and serve it on every later
    run. Only fully-elapsed days (strictly before today) are cacheable.
    """
    try:
        end = pd.Timestamp(end_date).normalize().date()
    except Exception:  # noqa: BLE001 - an unparseable date is treated as not cacheable
        return False
    return end < dt.date.today()


def loader_cache_get(
    *,
    source: str,
    symbol: str,
    timeframe: str,
    start_date: str,
    end_date: str,
    fields: list[str] | tuple[str, ...] | None = None,
) -> pd.DataFrame | None:
    """Return a cached DataFrame for one payload, or ``None`` on any miss.

    Misses include: cache disabled, range not yet settled, entry absent, or a
    corrupt entry. A corrupt entry is non-fatal — the caller falls back to the
    live provider.
    """
    if not loader_cache_enabled() or not loader_cache_range_is_final(end_date):
        return None
    cache_path = loader_cache_path(
        source=source,
        symbol=symbol,
        timeframe=timeframe,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
    )
    return _read_loader_cache_frame(cache_path)


def loader_cache_put(
    *,
    source: str,
    symbol: str,
    timeframe: str,
    start_date: str,
    end_date: str,
    fields: list[str] | tuple[str, ...] | None,
    frame: pd.DataFrame | None,
) -> None:
    """Write one non-empty DataFrame to the cache; a no-op when not cacheable.

    Skips a disabled cache, an unsettled range, and empty/non-DataFrame results.
    Write failures are swallowed so a fetch never fails because of the cache.
    """
    if not loader_cache_enabled() or not loader_cache_range_is_final(end_date):
        return
    if not isinstance(frame, pd.DataFrame) or frame.empty:
        return
    cache_path = loader_cache_path(
        source=source,
        symbol=symbol,
        timeframe=timeframe,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
    )
    _write_loader_cache_frame(cache_path, frame)


def cached_loader_fetch(
    *,
    source: str,
    symbol: str,
    timeframe: str,
    start_date: str,
    end_date: str,
    fields: list[str] | tuple[str, ...] | None,
    fetch: Callable[[], pd.DataFrame | None],
) -> pd.DataFrame | None:
    """Fetch one DataFrame through the opt-in local cache.

    Convenience wrapper over :func:`loader_cache_get` / :func:`loader_cache_put`
    for the common per-symbol loader loop: return the cached frame when present,
    otherwise call ``fetch`` and cache a non-empty result. Cache read/write
    failures are non-fatal and fall back to ``fetch``.
    """
    cached = loader_cache_get(
        source=source,
        symbol=symbol,
        timeframe=timeframe,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
    )
    if cached is not None:
        return cached

    frame = fetch()
    loader_cache_put(
        source=source,
        symbol=symbol,
        timeframe=timeframe,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        frame=frame,
    )
    return frame


def _loader_cache_payload(
    *,
    source: str,
    symbol: str,
    timeframe: str,
    start_date: str,
    end_date: str,
    fields: list[str] | tuple[str, ...] | None,
) -> dict[str, object]:
    return {
        "version": _LOADER_CACHE_VERSION,
        "source": str(source),
        "symbol": str(symbol),
        "timeframe": str(timeframe),
        "start_date": _normalize_cache_date(start_date),
        "end_date": _normalize_cache_date(end_date),
        "fields": [str(field) for field in (fields or ())],
    }


def _normalize_cache_date(value: str) -> str:
    return pd.Timestamp(value).strftime("%Y-%m-%d")


def _sanitize_cache_segment(value: str) -> str:
    cleaned = "".join(
        ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in value.strip().lower()
    )
    return cleaned or "unknown"


def _loader_cache_metadata_path(cache_path: Path) -> Path:
    return cache_path.with_suffix(cache_path.suffix + ".json")


def _read_loader_cache_frame(cache_path: Path) -> pd.DataFrame | None:
    if not cache_path.is_file():
        return None

    metadata_path = _loader_cache_metadata_path(cache_path)
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        # Every cache frame, including one with an unnamed RangeIndex, writes
        # explicit index metadata. Accepting {} or [] here silently turns a
        # dated series into row numbers and drops its adjustment/currency.
        if not isinstance(metadata, dict) or metadata.get("version") != _LOADER_CACHE_VERSION:
            raise ValueError("missing or incompatible cache metadata version")
        index_columns = metadata.get("index_columns")
        index_names = metadata.get("index_names")
        frame_attrs = metadata.get("frame_attrs")
        if (
            not isinstance(index_columns, list) or not index_columns
            or not all(isinstance(column, str) for column in index_columns)
            or len(set(index_columns)) != len(index_columns)
            or not isinstance(index_names, list) or len(index_names) != len(index_columns)
            or not isinstance(frame_attrs, dict)
            or any(
                name in frame_attrs and not isinstance(frame_attrs[name], str)
                for name in _LOADER_FRAME_METADATA_ATTRS
            )
        ):
            raise ValueError("invalid cache index or frame metadata")
    except Exception as exc:  # noqa: BLE001 - local cache miss is non-fatal
        logger.warning(
            "loader cache metadata read failed for %s: %s", cache_path.name, exc
        )
        return None

    con = None
    try:
        import duckdb

        con = duckdb.connect(database=":memory:")
        frame = con.execute(
            f"SELECT * FROM read_parquet({_duckdb_sql_string(cache_path)})"
        ).fetchdf()
    except Exception as exc:  # noqa: BLE001 - corrupt cache falls back to provider
        logger.warning("loader cache read failed for %s: %s", cache_path.name, exc)
        return None
    finally:
        if con is not None:
            con.close()

    try:
        index_columns = metadata.get("index_columns") or []
        if index_columns:
            missing = [
                column for column in index_columns if column not in frame.columns
            ]
            if missing:
                logger.warning(
                    "loader cache %s missing index column(s): %s",
                    cache_path.name,
                    missing,
                )
                return None
            frame = frame.set_index(index_columns)
            frame.index.names = metadata.get("index_names") or index_columns
            frame = _restore_cache_index_dtypes(frame, metadata.get("index_dtypes"))
        frame.columns.name = metadata.get("columns_name")
        frame_attrs = metadata.get("frame_attrs")
        if isinstance(frame_attrs, dict):
            for name in _LOADER_FRAME_METADATA_ATTRS:
                value = frame_attrs.get(name)
                if isinstance(value, str):
                    frame.attrs[name] = value
    except Exception as exc:  # noqa: BLE001 - corrupt metadata is a cache miss
        logger.warning(
            "loader cache metadata restore failed for %s: %s", cache_path.name, exc
        )
        return None

    return frame


def _restore_cache_index_dtypes(
    frame: pd.DataFrame, index_dtypes: object
) -> pd.DataFrame:
    """Best-effort restore of the per-level index dtypes recorded at write time.

    Cosmetic and non-fatal: duckdb parquet may rewrite datetime resolution, so
    we cast each level back to its original dtype. A failed cast leaves the
    duckdb-provided dtype rather than failing the read.
    """
    if not isinstance(index_dtypes, list) or frame.index.nlevels != len(index_dtypes):
        return frame
    try:
        if frame.index.nlevels == 1:
            frame.index = frame.index.astype(index_dtypes[0])
        else:
            for level, dtype in enumerate(index_dtypes):
                frame.index = frame.index.set_levels(
                    frame.index.levels[level].astype(dtype), level=level
                )
    except Exception:  # noqa: BLE001 - index dtype restore is cosmetic
        logger.debug("loader cache index dtype restore skipped: %s", index_dtypes)
    return frame


def _write_loader_cache_frame(cache_path: Path, frame: pd.DataFrame) -> None:
    metadata_path = _loader_cache_metadata_path(cache_path)
    # pid + uuid so two concurrent writers of the same key never share a tmp
    # path; os.replace then swaps each file in atomically.
    unique = f"{os.getpid()}.{uuid.uuid4().hex}"
    tmp_path = cache_path.with_name(f"{cache_path.name}.{unique}.tmp")
    tmp_metadata_path = metadata_path.with_name(f"{metadata_path.name}.{unique}.tmp")

    try:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_frame, metadata = _frame_for_loader_cache(frame)

        import duckdb

        con = duckdb.connect(database=":memory:")
        try:
            con.register("cache_frame", cache_frame)
            con.execute(
                f"COPY cache_frame TO {_duckdb_sql_string(tmp_path)} (FORMAT PARQUET)"
            )
        finally:
            con.close()

        tmp_metadata_path.write_text(
            json.dumps(metadata, sort_keys=True, separators=(",", ":")),
            encoding="utf-8",
        )
        os.replace(tmp_path, cache_path)
        os.replace(tmp_metadata_path, metadata_path)
    except (
        Exception
    ) as exc:  # noqa: BLE001 - cache write failures should not fail fetches
        logger.warning("loader cache write failed for %s: %s", cache_path.name, exc)
        for path in (tmp_path, tmp_metadata_path):
            try:
                path.unlink()
            except FileNotFoundError:
                pass
            except OSError:
                pass


def _frame_for_loader_cache(
    frame: pd.DataFrame,
) -> tuple[pd.DataFrame, dict[str, object]]:
    cache_frame = frame.copy()
    original_index_names = list(cache_frame.index.names)
    columns_name = cache_frame.columns.name
    index_dtypes = [
        str(cache_frame.index.get_level_values(level).dtype)
        for level in range(cache_frame.index.nlevels)
    ]
    index_columns = _cache_index_columns(cache_frame)
    cache_frame.index = cache_frame.index.set_names(index_columns)
    metadata: dict[str, object] = {
        "version": _LOADER_CACHE_VERSION,
        "index_columns": index_columns,
        "index_names": original_index_names,
        # Preserve the columns-axis name (e.g. yfinance leaves "Price") and the
        # per-level index dtypes so a cached frame round-trips byte-identical to
        # a freshly fetched one (duckdb parquet otherwise rewrites datetime
        # resolution, e.g. [s] -> [us]).
        "columns_name": None if columns_name is None else str(columns_name),
        "index_dtypes": index_dtypes,
        "frame_attrs": {
            name: frame.attrs[name]
            for name in _LOADER_FRAME_METADATA_ATTRS
            if isinstance(frame.attrs.get(name), str)
        },
    }
    return cache_frame.reset_index(), metadata


def _cache_index_columns(frame: pd.DataFrame) -> list[str]:
    columns = {str(column) for column in frame.columns}
    used: set[str] = set()
    index_columns: list[str] = []
    for pos, name in enumerate(frame.index.names):
        base = str(name) if name is not None else f"__vibe_loader_index_{pos}__"
        candidate = base
        suffix = 1
        while candidate in columns or candidate in used:
            candidate = f"{base}_{suffix}"
            suffix += 1
        index_columns.append(candidate)
        used.add(candidate)
    return index_columns


def _duckdb_sql_string(path: Path) -> str:
    return "'" + str(path).replace("'", "''") + "'"


@runtime_checkable
class DataLoaderProtocol(Protocol):
    """Interface that every data source loader must satisfy.

    Optional class attribute ``volume_units: dict[str, str]`` (not part of the
    structural check so existing loaders keep working): declares the unit of
    the ``volume`` column per market, keyed by market name — e.g.
    ``{"a_share": "lots", "hk_equity": "shares"}``. ``"lots"`` means board
    lots (1 A-share lot = 100 shares); ``"shares"`` means single shares.
    Sources differ natively (see HKUDS/Vibe-Trading#1062), so consumers must
    read the per-symbol ``volume_unit`` from ``_provenance`` instead of
    assuming a unit; a missing market entry surfaces as ``null`` (undeclared).
    """

    name: str
    markets: set[str]
    requires_auth: bool

    def is_available(self) -> bool:
        """Check whether this data source is usable (token present, network ok, etc.)."""
        ...

    def fetch(
        self,
        codes: list[str],
        start_date: str,
        end_date: str,
        *,
        interval: str = "1D",
        fields: list[str] | None = None,
    ) -> dict[str, pd.DataFrame]:
        """Fetch OHLCV data.

        Returns:
            Mapping ``{symbol: DataFrame(trade_date, open, high, low, close, volume)}``.
        """
        ...
