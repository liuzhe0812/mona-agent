"""China futures backtest engine.

Market rules (exchange-level, CFFEX / SHFE / DCE / ZCE / INE / GFEX):
  - T+0: can open and close same day (intraday trading allowed)
  - Margin trading: 5%~15% by product (exchange-set minimum)
  - Price limits: stock-index +-10%, bonds +-2%, commodities +-3%~8%
  - Commission: per-lot fixed or per-notional rate (varies by product)
  - Contract multiplier: product-specific (IF=300, rb=10, au=1000, ...)
  - Minimum trading unit: 1 contract
  - Night session: 21:00-02:30 (varies by product, not enforced in bar-level sim)
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, Hashable, Mapping, TypeVar

import pandas as pd

from backtest.engines.china_a import _blocked_by_limit
from backtest.engines.futures_base import FuturesBaseEngine

logger = logging.getLogger(__name__)

_T = TypeVar("_T")


# ── Contract multiplier lookup ──

_MULTIPLIER: dict[str, int] = {
    # Stock index futures (CFFEX)
    "IF": 300, "IC": 200, "IH": 300, "IM": 200,
    # Treasury bond futures (CFFEX)
    "T": 10000, "TF": 10000, "TS": 20000, "TL": 10000,
    # Metals (SHFE)
    "au": 1000, "ag": 15, "cu": 5, "al": 5, "zn": 5,
    "pb": 5, "ni": 1, "sn": 1, "ss": 5,
    # Ferrous (SHFE / DCE)
    "rb": 10, "hc": 10, "i": 100, "j": 100, "jm": 60,
    # Energy (SHFE / INE)
    "sc": 1000, "fu": 10, "lu": 10, "bu": 10, "nr": 10,
    # Agriculture (DCE)
    "c": 10, "cs": 10, "m": 10, "y": 10, "a": 10,
    "p": 10, "jd": 10, "lh": 16, "rr": 10, "pg": 20,
    # Agriculture (ZCE)
    "CF": 5, "SR": 10, "TA": 5, "MA": 10, "AP": 10,
    "RM": 10, "OI": 10, "CJ": 5, "PK": 5, "CY": 5,
    # Chemical (DCE / ZCE)
    "pp": 5, "l": 5, "v": 5, "eg": 10, "eb": 5,
    "PF": 5, "SA": 20, "FG": 20, "UR": 20,
    # GFEX
    "si": 5, "lc": 1,
}

# ── Margin rate (exchange minimum) ──

_MARGIN_RATE: dict[str, float] = {
    # CFFEX stock index
    "IF": 0.12, "IC": 0.12, "IH": 0.12, "IM": 0.12,
    # CFFEX bonds
    "T": 0.03, "TF": 0.02, "TS": 0.015, "TL": 0.035,
    # SHFE metals
    "au": 0.08, "ag": 0.09, "cu": 0.08, "al": 0.07,
    "zn": 0.08, "pb": 0.08, "ni": 0.12, "sn": 0.10, "ss": 0.08,
    # Ferrous
    "rb": 0.10, "hc": 0.10, "i": 0.12, "j": 0.12, "jm": 0.12,
    # Energy
    "sc": 0.10, "fu": 0.10, "lu": 0.10, "bu": 0.10,
    # Agriculture
    "c": 0.07, "cs": 0.07, "m": 0.08, "y": 0.08, "a": 0.08,
    "p": 0.08, "jd": 0.08, "lh": 0.12,
    # Textiles / chemical
    "CF": 0.07, "SR": 0.07, "TA": 0.07, "MA": 0.07,
    "pp": 0.07, "l": 0.07, "v": 0.07, "eg": 0.08,
    "SA": 0.08, "FG": 0.08, "UR": 0.08,
}

# ── Price limit (fraction, ± from settlement) ──

_PRICE_LIMIT: dict[str, float] = {
    # CFFEX stock index ±10%
    "IF": 0.10, "IC": 0.10, "IH": 0.10, "IM": 0.10,
    # CFFEX bonds ±2% (simplified)
    "T": 0.02, "TF": 0.012, "TS": 0.005, "TL": 0.035,
}
_DEFAULT_PRICE_LIMIT = 0.05  # most commodities ±4%~7%, use 5% as default

# ── Commission structure ──
# ("rate", pct) = per-notional  |  ("fixed", amount_per_lot) = per-contract

_COMMISSION: dict[str, tuple[str, float]] = {
    # CFFEX stock index: ~0.0023% of notional
    "IF": ("rate", 0.000023), "IC": ("rate", 0.000023),
    "IH": ("rate", 0.000023), "IM": ("rate", 0.000023),
    # CFFEX bonds
    "T": ("fixed", 3.0), "TF": ("fixed", 3.0), "TS": ("fixed", 3.0),
    # Metals
    "au": ("fixed", 10.0), "ag": ("fixed", 3.0), "cu": ("fixed", 5.0),
    "al": ("fixed", 3.0), "zn": ("fixed", 3.0), "ni": ("fixed", 3.0),
    # Ferrous
    "rb": ("rate", 0.0001), "hc": ("rate", 0.0001), "i": ("rate", 0.0001),
    "j": ("rate", 0.0001), "jm": ("rate", 0.0001),
    # Energy
    "sc": ("fixed", 20.0), "fu": ("rate", 0.00005),
    # Agriculture
    "c": ("fixed", 1.2), "cs": ("fixed", 1.5), "m": ("fixed", 1.5),
    "y": ("fixed", 2.5), "a": ("fixed", 2.0), "p": ("fixed", 2.5),
    "jd": ("rate", 0.00015), "lh": ("rate", 0.0002),
    # Textiles / chemical
    "CF": ("fixed", 4.3), "SR": ("fixed", 3.0), "TA": ("fixed", 3.0),
    "MA": ("fixed", 2.0), "pp": ("fixed", 1.0), "l": ("fixed", 1.0),
    "v": ("fixed", 1.0), "SA": ("fixed", 3.5), "FG": ("fixed", 3.0),
}
_DEFAULT_COMMISSION: tuple[str, float] = ("fixed", 5.0)
_DEFAULT_MULTIPLIER = 10
_DEFAULT_MARGIN_RATE = 0.10


#: Upper-cased product code -> the spelling the tables above actually use.
#: CFFEX/ZCE products are keyed uppercase (IF, CF) and SHFE/DCE/INE/GFEX
#: lowercase (au, rb), but a real ts_code is uppercase on every exchange
#: (CU2406.SHFE) and ``_is_china_futures`` already routes either casing here.
#: Folding once at extraction keeps every table lookup below case-blind; no
#: two products collide when upper-cased (asserted in the tests).
_CANONICAL_PRODUCT: dict[str, str] = {
    key.upper(): key
    for table in (_MULTIPLIER, _MARGIN_RATE, _PRICE_LIMIT, _COMMISSION)
    for key in table
}


def _extract_product(symbol: str) -> str:
    """Extract product code from futures symbol.

    The returned code is the one the product tables are keyed by, whatever
    casing the caller used: 'AU2412.SHFE' and 'au2412' both yield 'au'.

    Examples:
        'IF2406.CFFEX' -> 'IF'
        'rb2410.SHFE'  -> 'rb'
        'AU2412.SHFE'  -> 'au'

    Args:
        symbol: Futures symbol string.

    Returns:
        Product code as spelled in the tables (e.g. 'IF', 'rb', 'au'), or
        the raw letters when the product is not listed.
    """
    code = symbol.split(".")[0]
    m = re.match(r"([A-Za-z]+)", code)
    product = m.group(1) if m else code
    return _CANONICAL_PRODUCT.get(product.upper(), product)


class ChinaFuturesEngine(FuturesBaseEngine):
    """China futures engine covering CFFEX / SHFE / DCE / ZCE / INE / GFEX.

    Config keys:
      - slippage: default 0.0005
      - margin_rate_override: override margin rate for all products
      - commission_override: override commission for all products
    """

    #: (product, field) -> the generic constant this run was priced on. A
    #: product missing from a table does not fail, it silently takes a default
    #: (#1393), so the run has to say which numbers were assumed rather than
    #: looked up. Recording, not changing: every number stays what it was.
    _pricing_defaults: Dict[tuple[str, str], Any]

    def __init__(self, config: dict):
        self._pricing_defaults = {}
        # Derive leverage from margin rate of first code, or use config override
        margin_override = config.get("margin_rate_override")
        if margin_override:
            leverage = 1.0 / margin_override
        else:
            codes = config.get("codes", [])
            if codes:
                product = _extract_product(codes[0])
                mr = self._priced(_MARGIN_RATE, product, _DEFAULT_MARGIN_RATE, "margin_rate")
                leverage = 1.0 / mr
            else:
                leverage = 10.0  # ~10% margin default
        config = {**config, "leverage": leverage}
        super().__init__(config)
        # Futures bands come off the previous settlement, not the previous close.
        self.base_price_fields = ("pre_settle", "pre_close")
        self.slippage_rate: float = config.get("slippage", 0.0005)
        self._margin_rate_override = margin_override if margin_override else None
        self._commission_override = config.get("commission_override")

    def _priced(
        self,
        table: Mapping[str, _T],
        product: str,
        default: _T,
        field: str,
    ) -> _T:
        """Look a product up, recording the miss when it falls back.

        A product absent from one of the tables is priced on a generic
        constant that looks exactly like data in the output. This returns the
        same value the plain ``table.get(product, default)`` returned before
        and additionally remembers the miss, so the run can state which of its
        numbers were assumed.

        Args:
            table: One of the product tables in this module.
            product: Product code as ``_extract_product`` spells it.
            default: The generic constant used when the product is absent.
            field: Name of the field, as reported in ``pricing_assumptions``.

        Returns:
            The table entry, or ``default`` when the product is not listed.
        """
        if product in table:
            return table[product]
        key = (product, field)
        if key not in self._pricing_defaults:
            self._pricing_defaults[key] = default
            logger.warning(
                "China futures product %r has no %s entry; pricing it on the "
                "generic default %r. The backtest reports this under "
                "pricing_assumptions.",
                product,
                field,
                default,
            )
        return default

    def _engine_diagnostics(self) -> Dict[str, Any]:
        """Report every table lookup this run priced on a generic default."""
        if not self._pricing_defaults:
            return {}
        return {
            "pricing_assumptions": [
                {"product": product, "field": field, "value": value}
                for (product, field), value in sorted(self._pricing_defaults.items())
            ]
        }

    def can_execute(self, symbol: str, direction: int, bar: pd.Series) -> bool:
        """China futures: T+0, both directions, price-limit enforced.

        Args:
            symbol: Futures code.
            direction: 1 (long), -1 (short), 0 (close).
            bar: Current bar data.

        Returns:
            True if allowed.
        """
        # T+0: no same-day sell restriction
        # Both long and short allowed

        # Price limit, tested at execution time (see _blocked_by_limit).
        product = _extract_product(symbol)
        limit = self._priced(_PRICE_LIMIT, product, _DEFAULT_PRICE_LIMIT, "price_limit")
        pos = self.positions.get(symbol) if direction == 0 else None
        if pos is None and direction == 0:
            return True
        return not _blocked_by_limit(
            self,
            symbol,
            direction,
            bar,
            limit,
            position_direction=pos.direction if pos is not None else None,
        )

    def round_size(self, raw_size: float, price: float) -> float:
        """Minimum 1 contract, integer lots only."""
        return max(int(raw_size), 0)

    def calc_commission(self, size: float, price: float, _direction: int, is_open: bool) -> float:
        """Commission varies by product: fixed per-lot or percentage of notional.

        ``_direction`` is unused — reserved for future open/close-fee
        asymmetry (some products charge different rates for close-today).
        """
        if self._commission_override is not None:
            return size * price * self._commission_override
        return self.calc_commission_for_symbol(self._active_symbol, size, price, is_open)

    def calc_commission_for_symbol(
        self, symbol: str, size: float, price: float, is_open: bool,
    ) -> float:
        """Symbol-aware commission calculation.

        Args:
            symbol: Futures code.
            size: Number of contracts.
            price: Execution price.
            is_open: True for opening trade.

        Returns:
            Commission in RMB.
        """
        product = _extract_product(symbol)
        mode, value = self._priced(
            _COMMISSION, product, _DEFAULT_COMMISSION, "commission"
        )
        cm = self._priced(
            _MULTIPLIER, product, _DEFAULT_MULTIPLIER, "contract_multiplier"
        )
        if mode == "rate":
            return size * price * cm * value
        return size * value

    def apply_slippage(self, price: float, direction: int) -> float:
        """Futures slippage."""
        return price * (1 + direction * self.slippage_rate)

    def get_contract_multiplier(self, symbol: str) -> float:
        """Look up contract multiplier from product code."""
        product = _extract_product(symbol)
        return float(
            self._priced(_MULTIPLIER, product, _DEFAULT_MULTIPLIER, "contract_multiplier")
        )

    def get_margin_rate(self, symbol: str) -> float:
        """Look up exchange margin rate for a product.

        Args:
            symbol: Futures symbol.

        Returns:
            Margin rate (e.g. 0.10 for 10%).
        """
        product = _extract_product(symbol)
        return self._priced(_MARGIN_RATE, product, _DEFAULT_MARGIN_RATE, "margin_rate")

    def _leverage_for_symbol(self, symbol: str) -> float:
        """Derive leverage from this contract's own margin requirement."""
        if self._margin_rate_override is not None:
            return 1.0 / float(self._margin_rate_override)
        return 1.0 / self.get_margin_rate(symbol)


# ── Helpers ──

